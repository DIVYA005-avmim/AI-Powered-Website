export interface Destination {
  id: string;
  name: string;
  country: string;
  description: string;
  image: string;
  coordinates: string;
  altitude: string;
  localTime: string;
  flightDuration: string;
  highlights: string[];
  temperature: string;
  starRating: number;
}

export interface FlightStatus {
  altitude: number;
  speed: number;
  progress: number;
  cabinTemp: number;
  ambientLight: 'aurora' | 'midnight' | 'sunset' | 'cosmic';
  autopilot: boolean;
}
