import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { ChevronDown, Volume2, VolumeX, Eye, Info } from 'lucide-react';

interface HeroProps {
  onBeginJourney: () => void;
}

export default function Hero({ onBeginJourney }: HeroProps) {
  const [ambientSound, setAmbientSound] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Initialize a subtle ambient cabin sound
  useEffect(() => {
    // High-quality atmospheric relaxing synth / white noise loop
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-84.wav'); // Soft white noise / wind
    audio.loop = true;
    audio.volume = 0.2;
    audioRef.current = audio;

    return () => {
      audio.pause();
    };
  }, []);

  const toggleSound = () => {
    if (!audioRef.current) return;
    if (ambientSound) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(err => console.log("Audio play needs user click first", err));
    }
    setAmbientSound(!ambientSound);
  };

  return (
    <section
      id="home"
      className="relative w-full h-screen overflow-hidden flex flex-col justify-center items-center select-none"
    >
      {/* 1. Cinematic Background Video */}
      <div className="absolute inset-0 w-full h-full z-0">
        <video
          ref={videoRef}
          src="https://res.cloudinary.com/drzsabxvb/video/upload/v1784443678/Airplane_window_reveals_Eiffel_T__202607191128_umfnzf.mp4"
          autoPlay
          loop
          muted
          playsInline
          className="absolute top-1/2 left-1/2 min-w-full min-h-full w-auto h-auto -translate-x-1/2 -translate-y-1/2 object-cover"
          style={{ filter: 'brightness(0.9) contrast(1.05)' }}
        />
        {/* Subtle Dark Overlay: 30% to 40% opacity */}
        <div className="absolute inset-0 bg-gradient-to-b from-luxury-blue-950/40 via-luxury-blue-950/30 to-luxury-blue-950/70 z-10" />
      </div>

      {/* 2. Floating Atmospheric Cabin Window Overlay (To enhance depth / realism) */}
      <div className="absolute inset-0 pointer-events-none z-15 flex items-center justify-center">
        <div className="w-full h-full border-[24px] md:border-[48px] border-luxury-blue-950/20 rounded-3xl opacity-40 box-border pointer-events-none" />
      </div>

      {/* 3. Immersive Content Overlay */}
      <div className="relative z-20 max-w-5xl mx-auto px-6 text-center flex flex-col items-center justify-between h-[75%] pt-20">
        
        {/* Subtle Welcome Tag */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="mt-8 flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full backdrop-blur-md"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-gold-400 animate-pulse"></span>
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-slate-300 font-medium">
            Midnight Flight No. 707
          </span>
        </motion.div>

        {/* Main Header & Subtitle */}
        <div className="my-auto flex flex-col items-center">
          <motion.h1
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
            className="font-display font-extrabold text-4xl sm:text-6xl md:text-8xl text-white tracking-[0.12em] uppercase leading-none text-center"
          >
            <span className="block glow-text-gold">Travel Above</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-white to-gold-400 font-light tracking-[0.2em] mt-2 md:mt-4 text-3xl sm:text-5xl md:text-6xl">
              The Sky
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.6, ease: 'easeOut' }}
            className="max-w-2xl text-slate-300 font-sans text-sm sm:text-lg md:text-xl font-light tracking-wide leading-relaxed mt-8 text-center"
          >
            Experience a breathtaking journey above the clouds where every flight reveals a new destination.
          </motion.p>

          {/* Call to Action Trigger Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 1.0, ease: 'easeOut' }}
            className="mt-12"
          >
            <button
              onClick={onBeginJourney}
              className="group relative px-10 py-5 rounded-full font-display text-sm tracking-[0.25em] font-medium uppercase text-slate-100 border border-white/15 overflow-hidden shadow-2xl transition-all duration-500 hover:border-gold-400/40 cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%)',
                backdropFilter: 'blur(12px)',
                WebkitBackdropFilter: 'blur(12px)'
              }}
              id="begin-journey-btn"
            >
              {/* Button light sweep / glow effect */}
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer" />
              <span className="absolute inset-0 bg-gold-400/0 group-hover:bg-gold-400/5 transition-all duration-500 rounded-full" />
              <span className="relative flex items-center justify-center space-x-2 text-white group-hover:text-gold-400 transition-colors duration-500">
                <span>Begin the Journey</span>
              </span>
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[60px] h-[1px] bg-gold-400/60 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-[1px]"></span>
            </button>
          </motion.div>
        </div>

        {/* 4. Bottom Controls & Indicators */}
        <div className="w-full flex items-center justify-between pb-4">
          
          {/* Sound Toggle */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            onClick={toggleSound}
            className="flex items-center space-x-2.5 px-4 py-2 rounded-full glass-panel-light hover:bg-white/10 text-slate-400 hover:text-white transition-all duration-300 cursor-pointer text-xs font-mono tracking-wider"
            title="Toggle Ambient Flight Sound"
            id="sound-toggle-btn"
          >
            {ambientSound ? (
              <>
                <Volume2 className="w-4 h-4 text-gold-400" />
                <span className="text-gold-400 font-medium">AUDIO ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-slate-500" />
                <span>AUDIO OFF</span>
              </>
            )}
          </motion.button>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.8, duration: 1 }}
            className="flex flex-col items-center space-y-1 text-slate-400 hover:text-white transition-colors duration-300 cursor-pointer"
            onClick={onBeginJourney}
          >
            <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-slate-400">Scroll down</span>
            <motion.div
              animate={{ y: [0, 6, 0] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
            >
              <ChevronDown className="w-4 h-4 text-gold-400/80" />
            </motion.div>
          </motion.div>

          {/* Flight Data Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="hidden sm:flex items-center space-x-2 text-[10px] font-mono text-slate-400"
          >
            <Eye className="w-3.5 h-3.5 text-slate-500" />
            <span className="tracking-wide">VIEW: PORT-WINDOW</span>
          </motion.div>

        </div>
      </div>

      {/* Decorative vertical lines on sides to create depth and modular framing */}
      <div className="hidden lg:block absolute left-8 top-1/4 bottom-1/4 w-[1px] bg-gradient-to-b from-transparent via-white/5 to-transparent z-10" />
      <div className="hidden lg:block absolute right-8 top-1/4 bottom-1/4 w-[1px] bg-gradient-to-b from-transparent via-white/5 to-transparent z-10" />
    </section>
  );
}
