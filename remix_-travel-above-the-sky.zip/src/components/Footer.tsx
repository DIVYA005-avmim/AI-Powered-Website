import { Plane, Mail, ArrowUp, Instagram, Twitter, Linkedin } from 'lucide-react';

export default function Footer() {
  const handleScrollTop = () => {
    const target = document.getElementById('home');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer id="contact" className="relative bg-luxury-blue-950 border-t border-white/5 py-16 md:py-24 px-6 md:px-12 overflow-hidden z-10">
      
      {/* Background ambient light */}
      <div className="absolute bottom-0 right-1/4 w-[300px] h-[300px] rounded-full bg-gold-400/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Top Section: Newsletter Sign-up */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-16 border-b border-white/5 items-center">
          <div className="lg:col-span-6 space-y-3">
            <h4 className="font-display font-bold text-white text-xl sm:text-2xl uppercase tracking-wider">
              Subscribe to flight schedules
            </h4>
            <p className="text-slate-400 text-sm max-w-md font-sans font-light leading-relaxed">
              Get notified immediately when new flight corridors open and premium stratospheric itineraries are released.
            </p>
          </div>

          <div className="lg:col-span-6">
            <form onSubmit={(e) => e.preventDefault()} className="flex flex-col sm:flex-row gap-3 w-full" id="newsletter-form">
              <div className="relative flex-1">
                <input
                  type="email"
                  required
                  placeholder="Enter your VIP email address"
                  className="w-full glass-input rounded-xl pl-11 pr-4 py-3.5 text-xs sm:text-sm font-sans"
                  id="newsletter-email"
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              </div>
              <button
                type="submit"
                className="px-8 py-3.5 rounded-xl bg-white text-slate-950 font-display text-xs tracking-widest font-bold hover:bg-slate-200 transition-colors uppercase cursor-pointer"
                id="newsletter-submit-btn"
              >
                Dispatch
              </button>
            </form>
          </div>
        </div>

        {/* Middle Section: Organized Link Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-12 gap-8 md:gap-12 lg:gap-8">
          
          {/* Brand Dossier Column */}
          <div className="col-span-2 md:col-span-2 lg:col-span-4 space-y-6">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={handleScrollTop} id="footer-logo">
              <div className="w-10 h-10 rounded-full bg-gold-400/10 border border-gold-400/20 flex items-center justify-center">
                <Plane className="w-5 h-5 text-gold-400" />
              </div>
              <div>
                <span className="font-display font-bold tracking-[0.2em] text-white text-base block leading-none">
                  SKYLINE
                </span>
                <span className="font-mono text-[9px] text-gold-400/80 tracking-widest block uppercase mt-1">
                  Above The Sky
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm font-light">
              Crafting premium simulated flight experiences above the clouds, revealing the most stunning global landmarks through high-altitude digital flightdecks.
            </p>

            <div className="flex items-center space-x-4">
              <a href="#" className="p-2.5 rounded-full bg-white/5 border border-white/5 hover:border-gold-400/40 hover:text-gold-400 text-slate-400 transition-colors duration-300" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="p-2.5 rounded-full bg-white/5 border border-white/5 hover:border-gold-400/40 hover:text-gold-400 text-slate-400 transition-colors duration-300" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="p-2.5 rounded-full bg-white/5 border border-white/5 hover:border-gold-400/40 hover:text-gold-400 text-slate-400 transition-colors duration-300" aria-label="Linkedin">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Spacer on Desktop */}
          <div className="hidden lg:block lg:col-span-2" />

          {/* Column 2: Navigation */}
          <div className="col-span-1 md:col-span-1 lg:col-span-2 space-y-4">
            <h5 className="font-mono text-[10px] text-slate-500 uppercase tracking-widest font-bold">
              Flight Paths
            </h5>
            <ul className="space-y-2.5 text-xs text-slate-400 font-sans font-light">
              <li><a href="#home" className="hover:text-gold-400 transition-colors">Home Landing</a></li>
              <li><a href="#journey" className="hover:text-gold-400 transition-colors">Cruising Story</a></li>
              <li><a href="#destinations" className="hover:text-gold-400 transition-colors">Destinations</a></li>
              <li><a href="#experience" className="hover:text-gold-400 transition-colors">Flight Deck</a></li>
            </ul>
          </div>

          {/* Column 3: Resources */}
          <div className="col-span-1 md:col-span-1 lg:col-span-2 space-y-4">
            <h5 className="font-mono text-[10px] text-slate-500 uppercase tracking-widest font-bold">
              Cabin Extras
            </h5>
            <ul className="space-y-2.5 text-xs text-slate-400 font-sans font-light">
              <li><a href="#experience" className="hover:text-gold-400 transition-colors">Pass Printer</a></li>
              <li><a href="#journey" className="hover:text-gold-400 transition-colors">Altitude Controller</a></li>
              <li><a href="#home" className="hover:text-gold-400 transition-colors">Ambient Audio</a></li>
              <li><a href="#destinations" className="hover:text-gold-400 transition-colors">Eiffel Tower view</a></li>
            </ul>
          </div>

          {/* Column 4: Legals */}
          <div className="col-span-2 md:col-span-1 lg:col-span-2 space-y-4">
            <h5 className="font-mono text-[10px] text-slate-500 uppercase tracking-widest font-bold">
              Regulations
            </h5>
            <ul className="space-y-2.5 text-xs text-slate-400 font-sans font-light">
              <li><a href="#" className="hover:text-gold-400 transition-colors">Terms of Boarding</a></li>
              <li><a href="#" className="hover:text-gold-400 transition-colors">Sky Privacy Policy</a></li>
              <li><a href="#" className="hover:text-gold-400 transition-colors">Stratosphere Code</a></li>
              <li><a href="#" className="hover:text-gold-400 transition-colors">Airport Licensing</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Section: Copyright & Scroll Top */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-slate-500">
          <span>
            © {currentYear} SKYLINE LUXURY SIMULATION. ALL RIGHTS RESERVED.
          </span>
          
          <button
            onClick={handleScrollTop}
            className="group py-2 px-4 rounded-xl bg-white/5 border border-white/5 hover:border-gold-400/40 text-slate-400 hover:text-white transition-all duration-300 flex items-center space-x-2 cursor-pointer"
            id="scroll-top-btn"
          >
            <span>Return to Flightdeck</span>
            <ArrowUp className="w-3.5 h-3.5 text-gold-400 group-hover:-translate-y-0.5 transition-transform duration-300" />
          </button>
        </div>

      </div>
    </footer>
  );
}
