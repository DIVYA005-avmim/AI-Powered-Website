import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Destination } from '../types';
import { Compass, Calendar, ArrowUpRight, MapPin, Eye, Thermometer, Clock, Star } from 'lucide-react';

const DESTINATIONS_DATA: Destination[] = [
  {
    id: 'paris',
    name: 'Paris',
    country: 'France',
    description: 'Sailing through the night sky to witness Paris from above. The Eiffel Tower pierces the clouds with its giant golden searchlight, sweeping across the dark French landscape like a lighthouse in a sea of stars.',
    image: '/src/assets/images/paris_eiffel_midnight_1784444028753.jpg',
    coordinates: '48° 51\' 24" N / 2° 21\' 8" E',
    altitude: '38,000 FT',
    localTime: '08:52 AM',
    flightDuration: '2h 15m (Cruise)',
    highlights: ['Midnight Eiffel Tower sparkle', 'Cruising over the Seine River', 'Glowing city arrondissements'],
    temperature: '18°C',
    starRating: 5
  },
  {
    id: 'tokyo',
    name: 'Tokyo',
    country: 'Japan',
    description: 'Descending over Tokyo Bay as a glowing circuit board of pure energy unfolds below. Skyscraper clusters glow in brilliant cobalt blue and warm amber, while the majestic Mount Fuji stands guard on the horizon.',
    image: '/src/assets/images/tokyo_midnight_glow_1784443978327.jpg',
    coordinates: '35° 41\' 22" N / 139° 41\' 30" E',
    altitude: '39,500 FT',
    localTime: '03:52 PM',
    flightDuration: '11h 45m (Direct)',
    highlights: ['Neon grid glow from above', 'Mount Fuji moonlight shadow', 'Glittering Rainbow Bridge'],
    temperature: '21°C',
    starRating: 5
  },
  {
    id: 'maldives',
    name: 'Maldives',
    country: 'Indian Ocean',
    description: 'An otherworldly arrival over a scattered chain of glowing coral atolls. From the cockpit window, the ocean reflects the stars perfectly, while neon blue bioluminescent waves fringe the pitch-black shorelines.',
    image: '/src/assets/images/maldives_night_glow_1784443994484.jpg',
    coordinates: '3° 12\' 0" N / 73° 0\' 0" E',
    altitude: '36,000 FT',
    localTime: '11:52 AM',
    flightDuration: '9h 30m (Direct)',
    highlights: ['Bioluminescent coastlines', 'Overwater bungalow silhouettes', 'Milky Way ocean reflections'],
    temperature: '28°C',
    starRating: 5
  },
  {
    id: 'newyork',
    name: 'New York',
    country: 'United States',
    description: 'Approaching the East Coast standard flight corridor. The entire island of Manhattan shines like an intricate bar of diamonds under the star-swept sky, framed by the dark, glassy bands of the Hudson and East rivers.',
    image: '/src/assets/images/new_york_dusk_glow_1784444012027.jpg',
    coordinates: '40° 42\' 46" N / 74° 0\' 21" W',
    altitude: '41,000 FT',
    localTime: '02:52 AM',
    flightDuration: '7h 10m (Direct)',
    highlights: ['Manhattan core skyline grid', 'Glowing Hudson River borders', 'Empire State light spire'],
    temperature: '15°C',
    starRating: 5
  }
];

export default function Destinations() {
  const [selectedDestId, setSelectedDestId] = useState<string>('paris');

  const selectedDest = DESTINATIONS_DATA.find((dest) => dest.id === selectedDestId) || DESTINATIONS_DATA[0];

  return (
    <section
      id="destinations"
      className="relative min-h-screen py-24 md:py-32 bg-luxury-blue-900 px-6 md:px-12 flex flex-col justify-center items-center"
    >
      {/* Background visual graphics */}
      <div className="absolute top-10 right-10 w-96 h-96 bg-blue-900/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[500px] h-[500px] bg-gold-400/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl w-full mx-auto space-y-16">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full backdrop-blur-md">
            <Compass className="w-4 h-4 text-gold-400" />
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-slate-300 font-medium">
              Curated Destinations
            </span>
          </div>
          
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-white tracking-wider uppercase leading-tight">
            Discover Breathtaking <br className="hidden sm:block"/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-white to-gold-400 font-light italic">
              Wonders from the Cabin
            </span>
          </h2>
          
          <p className="text-slate-400 font-sans text-sm max-w-xl mx-auto font-light leading-relaxed">
            Select an iconic destination below to access live flight coordinates, cruising altitude telemetry, and local conditions as we prepare for descent.
          </p>
        </div>

        {/* Main Content: Left Cards Selector, Right Dossier Briefing */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Left Column: Vertical cards selector (Grid on mobile, vertical stack on desktop) */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 w-full">
            {DESTINATIONS_DATA.map((dest) => {
              const isSelected = dest.id === selectedDestId;
              return (
                <button
                  key={dest.id}
                  onClick={() => setSelectedDestId(dest.id)}
                  className={`relative overflow-hidden text-left rounded-2xl border transition-all duration-500 cursor-pointer p-4 group flex items-center space-x-4 ${
                    isSelected
                      ? 'bg-luxury-blue-800/40 border-gold-400/50 glow-border-gold scale-[1.01]'
                      : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/15'
                  }`}
                  id={`dest-card-${dest.id}`}
                >
                  {/* Thumbnail */}
                  <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 relative border border-white/10">
                    <img
                      src={dest.image}
                      alt={dest.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-black/20" />
                  </div>

                  {/* Details */}
                  <div className="flex-1 space-y-1 overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="font-display font-bold text-white text-base tracking-wide uppercase">
                        {dest.name}
                      </span>
                      <ArrowUpRight className={`w-4 h-4 transition-transform duration-300 ${
                        isSelected ? 'text-gold-400 translate-x-0.5 -translate-y-0.5' : 'text-slate-500 group-hover:text-slate-300'
                      }`} />
                    </div>
                    
                    <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-400">
                      <MapPin className="w-3 h-3 text-gold-400/80 shrink-0" />
                      <span className="truncate">{dest.country}</span>
                    </div>

                    <div className="flex items-center space-x-3 text-[10px] font-mono text-slate-500 pt-1">
                      <span>{dest.flightDuration}</span>
                      <span>•</span>
                      <span className="text-emerald-400">{dest.temperature}</span>
                    </div>
                  </div>

                  {/* Border Accent Line on Left side of Card */}
                  {isSelected && (
                    <div className="absolute left-0 top-3 bottom-3 w-[3px] bg-gold-400 rounded-r-md" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Column: Premium Flight Dossier / Boarding Pass */}
          <div className="lg:col-span-7 w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedDest.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.5 }}
                className="glass-card rounded-2xl overflow-hidden shadow-2xl relative"
                id={`dest-dossier-${selectedDest.id}`}
              >
                {/* Big Image Banner */}
                <div className="h-64 sm:h-80 relative overflow-hidden border-b border-white/5">
                  <img
                    src={selectedDest.image}
                    alt={selectedDest.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  {/* Subtle shadows and overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-luxury-blue-900 via-luxury-blue-900/30 to-transparent" />
                  
                  {/* Floating Telemetry Box inside image */}
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md border border-white/10 px-3.5 py-1.5 rounded-lg font-mono text-[10px] text-slate-300 flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>FLIGHT PATH LOCK</span>
                  </div>

                  {/* Header Title Layer */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="flex items-center space-x-2.5 text-[11px] font-mono text-gold-400 tracking-widest uppercase mb-1.5">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{selectedDest.country}</span>
                    </div>
                    <h3 className="font-display font-extrabold text-3xl sm:text-4xl text-white tracking-wider uppercase leading-none">
                      {selectedDest.name}
                    </h3>
                  </div>
                </div>

                {/* Dossier Specifications Body */}
                <div className="p-6 sm:p-8 space-y-6">
                  
                  {/* Summary Text */}
                  <p className="text-slate-300 text-sm sm:text-base leading-relaxed font-light">
                    {selectedDest.description}
                  </p>

                  {/* Telemetry Instrument Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-white/5 font-mono text-xs">
                    
                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 space-y-1">
                      <div className="flex items-center space-x-1.5 text-slate-500">
                        <Compass className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-[10px] uppercase">COORDINATES</span>
                      </div>
                      <span className="text-white text-xs block truncate tracking-tight">{selectedDest.coordinates}</span>
                    </div>

                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 space-y-1">
                      <div className="flex items-center space-x-1.5 text-slate-500">
                        <Eye className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-[10px] uppercase">ALTITUDE LOCK</span>
                      </div>
                      <span className="text-emerald-400 font-medium block">{selectedDest.altitude}</span>
                    </div>

                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 space-y-1">
                      <div className="flex items-center space-x-1.5 text-slate-500">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-[10px] uppercase">EST FLIGHT</span>
                      </div>
                      <span className="text-white block">{selectedDest.flightDuration}</span>
                    </div>

                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 space-y-1">
                      <div className="flex items-center space-x-1.5 text-slate-500">
                        <Thermometer className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-[10px] uppercase">TEMP LOCK</span>
                      </div>
                      <span className="text-amber-400 font-medium block">{selectedDest.temperature}</span>
                    </div>

                  </div>

                  {/* Experience Highlights / Story Bulletins */}
                  <div className="space-y-3 pt-2">
                    <h5 className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block">
                      CHRONO-HIGHLIGHTS IN SIGHT
                    </h5>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="highlights-grid">
                      {selectedDest.highlights.map((highlight, idx) => (
                        <div
                          key={idx}
                          className="flex items-center space-x-2.5 px-3.5 py-2.5 rounded-xl bg-white/[0.02] border border-white/5 font-sans text-xs text-slate-300"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-gold-400 shrink-0" />
                          <span className="truncate">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Interactive Button mimicking Boarding Action */}
                  <div className="pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center space-x-1">
                      {[...Array(selectedDest.starRating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-gold-400 text-gold-400" />
                      ))}
                      <span className="font-mono text-[10px] text-slate-500 ml-2 uppercase">Luxe Class Selection</span>
                    </div>

                    <button
                      onClick={() => {
                        const target = document.getElementById('experience');
                        if (target) target.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gold-400 text-slate-950 font-display text-xs tracking-widest font-semibold hover:bg-gold-500 transition-all duration-300 uppercase shadow-lg shadow-gold-400/10 hover:shadow-gold-400/20 flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      <span>Simulate Flight Descent</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>

                </div>
              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
