import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Radio, Users, Sparkles, Sliders, Play, Pause, Compass, Check, Calendar, RotateCcw } from 'lucide-react';

export default function Experience() {
  const [passengerName, setPassengerName] = useState('VIP Voyager');
  const [cabinClass, setCabinClass] = useState<'First Class' | 'Suites' | 'Private Jet'>('First Class');
  const [destination, setDestination] = useState('Paris (CDG)');
  const [ambientLight, setAmbientLight] = useState<'aurora' | 'midnight' | 'sunset' | 'cosmic'>('midnight');
  const [autopilot, setAutopilot] = useState(true);
  const [ticketPrinted, setTicketPrinted] = useState(false);
  const [boardingTime, setBoardingTime] = useState('');

  // Generate today's date for boarding pass
  useEffect(() => {
    const today = new Date();
    const formatted = today.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
    setBoardingTime(formatted);
  }, []);

  const getAmbientColors = () => {
    switch (ambientLight) {
      case 'aurora':
        return 'from-emerald-950/40 via-purple-950/30 to-luxury-blue-950 shadow-[0_0_50px_rgba(16,185,129,0.15)]';
      case 'sunset':
        return 'from-amber-950/40 via-red-950/30 to-luxury-blue-950 shadow-[0_0_50px_rgba(245,158,11,0.15)]';
      case 'cosmic':
        return 'from-indigo-950/40 via-sky-950/30 to-luxury-blue-950 shadow-[0_0_50px_rgba(56,189,248,0.15)]';
      case 'midnight':
      default:
        return 'from-luxury-blue-900/40 via-luxury-blue-800/30 to-luxury-blue-950 shadow-[0_0_50px_rgba(255,255,255,0.05)]';
    }
  };

  const getAmbientGlowText = () => {
    switch (ambientLight) {
      case 'aurora':
        return 'text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.3)]';
      case 'sunset':
        return 'text-amber-400 drop-shadow-[0_0_10px_rgba(245,158,11,0.3)]';
      case 'cosmic':
        return 'text-sky-400 drop-shadow-[0_0_10px_rgba(56,189,248,0.3)]';
      case 'midnight':
      default:
        return 'text-gold-400 drop-shadow-[0_0_10px_rgba(245,158,11,0.3)]';
    }
  };

  const getSeatNo = () => {
    if (cabinClass === 'Suites') return 'SUITE 01';
    if (cabinClass === 'Private Jet') return 'JET 1A';
    return 'SEAT 03B';
  };

  return (
    <section
      id="experience"
      className="relative min-h-screen py-24 md:py-32 bg-luxury-blue-950 px-6 md:px-12 flex flex-col justify-center items-center"
    >
      {/* Immersive cabin environment dynamic overlay lights based on ambient state */}
      <div className="absolute inset-0 transition-all duration-1000 ease-in-out pointer-events-none z-0">
        <div className={`absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-b ${getAmbientColors()} opacity-80`} />
      </div>

      <div className="max-w-7xl w-full mx-auto space-y-16 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full backdrop-blur-md">
            <Sliders className="w-4 h-4 text-gold-400" />
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-slate-300 font-medium">
              Cabin Control & Boarding
            </span>
          </div>
          
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-white tracking-wider uppercase leading-tight">
            Immerse In Your <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-white to-gold-400 font-light italic">
              Cinematic Journey
            </span>
          </h2>
          
          <p className="text-slate-400 font-sans text-sm max-w-xl mx-auto font-light leading-relaxed">
            Customize your boarding particulars, choose your cabin class, control the ambient lighting, and generate your premium flight clearance pass below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: Interactive Settings Cockpit Panel */}
          <div className="lg:col-span-5 flex flex-col justify-between glass-card rounded-2xl p-6 sm:p-8 space-y-8 h-full">
            <div className="space-y-6">
              <h3 className="font-display font-bold text-white text-lg tracking-wider uppercase flex items-center space-x-3 border-b border-white/5 pb-3">
                <Sliders className="w-5 h-5 text-gold-400" />
                <span>FLIGHT DESK HUD</span>
              </h3>

              {/* 1. Passenger Name */}
              <div className="space-y-2">
                <label className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                  PASSENGER IDENTITY
                </label>
                <input
                  type="text"
                  maxLength={20}
                  value={passengerName}
                  onChange={(e) => setPassengerName(e.target.value || 'VIP Voyager')}
                  placeholder="Enter Voyager Name"
                  className="w-full glass-input rounded-xl px-4 py-3 text-sm font-sans"
                  id="cabin-passenger-name"
                />
              </div>

              {/* 2. Cabin Class Select */}
              <div className="space-y-2">
                <label className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                  CABIN EXCLUSIVITY LEVEL
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['First Class', 'Suites', 'Private Jet'] as const).map((cl) => (
                    <button
                      key={cl}
                      onClick={() => setCabinClass(cl)}
                      className={`py-2 px-1 rounded-xl text-[11px] font-display uppercase tracking-wider border cursor-pointer transition-all duration-300 ${
                        cabinClass === cl
                          ? 'bg-gold-400/10 border-gold-400 text-gold-400 font-semibold'
                          : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                      id={`cabin-class-btn-${cl.replace(' ', '-')}`}
                    >
                      {cl}
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Choose Destination */}
              <div className="space-y-2">
                <label className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                  FLIGHT TARGET DESTINATION
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Paris (CDG)', 'Tokyo (HND)', 'Maldives (MLE)', 'New York (JFK)'].map((dest) => (
                    <button
                      key={dest}
                      onClick={() => setDestination(dest)}
                      className={`py-2.5 px-3 text-left rounded-xl text-xs font-mono border cursor-pointer transition-all duration-300 flex items-center justify-between ${
                        destination === dest
                          ? 'bg-gold-400/10 border-gold-400 text-gold-400 font-semibold'
                          : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                      id={`cabin-dest-btn-${dest.replace(/[\(\)\s]/g, '')}`}
                    >
                      <span>{dest}</span>
                      {destination === dest && <Check className="w-3.5 h-3.5 text-gold-400" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* 4. Ambient Cabin Lighting controls */}
              <div className="space-y-2">
                <label className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                  CABIN LED LIGHTING EMITTER
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'midnight', label: 'Silver', bg: 'bg-slate-400' },
                    { id: 'aurora', label: 'Aurora', bg: 'bg-emerald-400' },
                    { id: 'sunset', label: 'Sunset', bg: 'bg-amber-400' },
                    { id: 'cosmic', label: 'Cosmic', bg: 'bg-sky-400' }
                  ].map((light) => (
                    <button
                      key={light.id}
                      onClick={() => setAmbientLight(light.id as any)}
                      className={`py-2 rounded-xl text-[9px] font-mono uppercase tracking-widest border cursor-pointer transition-all duration-300 flex flex-col items-center justify-center space-y-1 ${
                        ambientLight === light.id
                          ? 'border-gold-400 bg-gold-400/10 text-gold-400 font-semibold'
                          : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                      id={`cabin-light-btn-${light.id}`}
                    >
                      <div className={`w-2.5 h-2.5 rounded-full ${light.bg} shadow-md`} />
                      <span>{light.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 5. Autopilot Lock */}
              <div className="flex items-center justify-between bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <div className="flex items-center space-x-2.5">
                  <span className={`w-2 h-2 rounded-full ${autopilot ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                  <span className="font-mono text-[10px] text-slate-300 uppercase tracking-wider">AUTO-PILOT LOCK</span>
                </div>
                <button
                  onClick={() => setAutopilot(!autopilot)}
                  className={`px-3 py-1 rounded-lg font-mono text-[9px] cursor-pointer transition-all duration-300 uppercase ${
                    autopilot
                      ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                      : 'bg-rose-500/10 border border-rose-500/20 text-rose-400'
                  }`}
                  id="autopilot-toggle-btn"
                >
                  {autopilot ? 'ENGAGED' : 'STANDBY'}
                </button>
              </div>

            </div>

            {/* Print Boarding Clearance Button */}
            <div className="pt-4 border-t border-white/5">
              <button
                onClick={() => setTicketPrinted(true)}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-gold-400 to-gold-500 text-slate-950 font-display text-xs tracking-widest font-bold hover:brightness-110 shadow-lg shadow-gold-500/15 cursor-pointer uppercase transition-all duration-300 flex items-center justify-center space-x-2"
                id="generate-ticket-btn"
              >
                <Sparkles className="w-4 h-4" />
                <span>PRINT CINEMATIC TICKET</span>
              </button>
            </div>
          </div>

          {/* Right Column: Beautiful Rendered Boarding Pass & Cockpit Radar */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <AnimatePresence mode="wait">
              {ticketPrinted ? (
                /* Dynamic Custom Boarding Pass rendering */
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, rotateY: -30 }}
                  animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.6, type: 'spring' }}
                  className="glass-card rounded-2xl overflow-hidden relative border border-white/10 shadow-[0_30px_70px_rgba(0,0,0,0.5)] bg-gradient-to-br from-luxury-blue-900/90 to-luxury-blue-950/95"
                  id="generated-boarding-pass"
                >
                  {/* Decorative glowing backlights representing selected ambient light style */}
                  <div className={`absolute -top-12 -right-12 w-48 h-48 rounded-full blur-[70px] pointer-events-none transition-all duration-1000 bg-current ${getAmbientColors()}`} />

                  {/* Header strip */}
                  <div className="bg-white/5 border-b border-white/5 py-4 px-6 sm:px-8 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <Radio className="w-4 h-4 text-gold-400 animate-pulse" />
                      <span className="font-mono text-xs text-gold-400 tracking-[0.2em] uppercase font-bold">
                        SKYLINE BOARDING CLEARANCE
                      </span>
                    </div>
                    <span className="font-mono text-[9px] text-slate-500 font-bold uppercase tracking-widest">
                      SUITE CLASS #707
                    </span>
                  </div>

                  {/* Main Ticket Layout */}
                  <div className="p-6 sm:p-8 space-y-6">
                    {/* Destination Banner Grid */}
                    <div className="grid grid-cols-5 gap-4 items-center border-b border-white/5 pb-6">
                      <div className="col-span-2 space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase">DEPARTURE</span>
                        <h4 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-widest uppercase">
                          LND
                        </h4>
                        <span className="font-sans text-[11px] text-slate-400 block truncate">London Heathrow</span>
                      </div>
                      
                      {/* Connection graphics */}
                      <div className="col-span-1 flex flex-col items-center justify-center space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase">FLIGHT</span>
                        <div className="relative flex items-center justify-center w-full">
                          <div className="w-full h-[1px] bg-dashed border-t border-white/10" />
                          <div className="absolute rounded-full p-1 bg-white/5 border border-white/10">
                            <Compass className="w-3.5 h-3.5 text-gold-400 animate-spin" style={{ animationDuration: '20s' }} />
                          </div>
                        </div>
                        <span className="font-mono text-[9px] text-gold-400 uppercase tracking-widest font-semibold mt-1">SL-707</span>
                      </div>

                      <div className="col-span-2 text-right space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase">ARRIVAL</span>
                        <h4 className={`font-display font-extrabold text-2xl sm:text-3xl tracking-widest uppercase ${getAmbientGlowText()}`}>
                          {destination.split(' ')[0].slice(0, 3).toUpperCase()}
                        </h4>
                        <span className="font-sans text-[11px] text-slate-400 block truncate">{destination}</span>
                      </div>
                    </div>

                    {/* Passenger Specs Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 py-2">
                      <div className="space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase block">PASSENGER NAME</span>
                        <span className="font-display font-bold text-white text-sm uppercase tracking-wide truncate block">{passengerName}</span>
                      </div>

                      <div className="space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase block">SEAT / CABIN</span>
                        <span className="font-mono text-xs text-gold-400 font-semibold block uppercase tracking-wider">{getSeatNo()}</span>
                      </div>

                      <div className="space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase block">EXCLUSIVITY CL</span>
                        <span className="font-display font-medium text-slate-300 text-xs block uppercase tracking-wider">{cabinClass}</span>
                      </div>

                      <div className="space-y-1">
                        <span className="font-mono text-[9px] text-slate-500 uppercase block">BOARDING DATE</span>
                        <span className="font-mono text-xs text-slate-300 block">{boardingTime || 'JULY 19, 2026'}</span>
                      </div>
                    </div>

                    {/* QR Code and barcode simulator panel */}
                    <div className="bg-white/5 border border-white/5 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row justify-between items-center gap-6">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center space-x-2">
                          <Check className="w-4 h-4 text-emerald-400" />
                          <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-wider">BOARDING APPROVAL CONFIRMED</span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-sans font-light leading-relaxed">
                          Your luxury digital pass has been successfully integrated into your navigation dossier. Please proceed to the cabin deck.
                        </p>
                      </div>

                      {/* Simulated Barcode */}
                      <div className="flex flex-col items-center space-y-1.5 shrink-0 bg-white/5 p-3 rounded-xl border border-white/5">
                        <div className="flex items-center space-x-[1.5px] h-10 w-36">
                          {[2, 4, 1, 3, 1, 4, 2, 1, 3, 1, 2, 4, 1, 2, 3, 1, 4, 2, 1, 3].map((w, idx) => (
                            <div key={idx} className="h-full bg-slate-300 rounded-sm" style={{ width: `${w * 1.5}px` }} />
                          ))}
                        </div>
                        <span className="font-mono text-[9px] text-slate-500 tracking-[0.2em]">SL_707_VIP_BOARD</span>
                      </div>
                    </div>

                  </div>

                  {/* Reset button inside pass footer */}
                  <div className="bg-white/5 border-t border-white/5 py-4 px-6 sm:px-8 flex items-center justify-between text-xs">
                    <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest flex items-center space-x-2">
                      <span className={`w-1.5 h-1.5 rounded-full ${autopilot ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      <span>HUD LOCK v2.4</span>
                    </span>
                    <button
                      onClick={() => setTicketPrinted(false)}
                      className="font-mono text-[10px] text-slate-400 hover:text-white uppercase tracking-widest flex items-center space-x-1 cursor-pointer"
                      id="reset-ticket-btn"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-gold-400" />
                      <span>RE-PRINT PASS</span>
                    </button>
                  </div>

                </motion.div>
              ) : (
                /* Cockpit Radar Simulator when pass is not printed yet */
                <motion.div
                  key="cockpit-hud"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="glass-card rounded-2xl p-6 sm:p-8 space-y-8 flex flex-col justify-center items-center min-h-[460px] text-center"
                  id="cockpit-radar-hud"
                >
                  {/* Rotating radar graphic */}
                  <div className="relative w-48 h-48 rounded-full border border-white/10 flex items-center justify-center overflow-hidden bg-black/40">
                    
                    {/* Rotating grid sweep */}
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.03)_0%,transparent_70%)]" />
                    
                    {/* Concentric rings */}
                    <div className="absolute w-36 h-36 rounded-full border border-dashed border-white/5" />
                    <div className="absolute w-24 h-24 rounded-full border border-white/5" />
                    <div className="absolute w-12 h-12 rounded-full border border-dashed border-white/5" />

                    {/* Sweeping bar */}
                    <div className="absolute inset-0 origin-center animate-spin" style={{ animationDuration: '6s', backgroundImage: 'conic-gradient(from 0deg, rgba(245,158,11,0.15) 0deg, transparent 90deg, transparent 360deg)' }} />

                    {/* Blinking flight target dot (represents Paris CDs) */}
                    <div className="absolute top-1/4 right-1/3 flex items-center justify-center">
                      <span className="absolute w-2 h-2 rounded-full bg-gold-400 animate-ping opacity-75" />
                      <span className="w-1.5 h-1.5 rounded-full bg-gold-400" />
                    </div>

                    <Compass className="w-8 h-8 text-slate-700/60" />
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-display font-bold text-white uppercase tracking-wider text-base">
                      Awaiting Boarding Particulars
                    </h4>
                    <p className="text-slate-400 text-xs max-w-sm mx-auto font-light leading-relaxed">
                      Please enter your name and select your flight configurations on the left console, then click <strong className="text-gold-400">"Print Cinematic Ticket"</strong> to issue your boarding clearance.
                    </p>
                  </div>

                  <div className="flex justify-center items-center space-x-6 text-[11px] font-mono text-slate-500 pt-2 border-t border-white/5 w-full max-w-sm">
                    <div className="flex items-center space-x-1.5">
                      <Users className="w-3.5 h-3.5 text-slate-600" />
                      <span>SEATING: SUITE 1A</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center space-x-1.5">
                      <Compass className="w-3.5 h-3.5 text-slate-600 animate-spin" style={{ animationDuration: '30s' }} />
                      <span>RADAR ACTIVE</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
