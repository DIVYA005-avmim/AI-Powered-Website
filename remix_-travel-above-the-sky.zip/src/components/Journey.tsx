import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Compass, Cloud, Sparkles, Navigation, ArrowRight } from 'lucide-react';

export default function Journey() {
  const [activeLevel, setActiveLevel] = useState(3); // Default at 38,000 ft

  const flightLevels = [
    {
      level: 1,
      altitude: '5,000 FT',
      title: 'Departure & Ascent',
      indicator: 'Takeoff Phase',
      description: 'The airplane lifts off, bank angles tilt, and the sprawling metropolitan lights begin to shrink into a sparkling grid of gold and silver below.',
      speed: '280 knots',
      temp: '12°C',
      view: 'Glittering city horizons fading into the rising night mist.'
    },
    {
      level: 2,
      altitude: '18,000 FT',
      title: 'Penetrating the Clouds',
      indicator: 'Climb Phase',
      description: 'Ascending through the cloud ceiling. Wispy sheets of silver-grey mist brush against the window as the flight transitions into the serene upper layers.',
      speed: '410 knots',
      temp: '-15°C',
      view: 'Entering a sea of cumulus layers glowing under the moonlight.'
    },
    {
      level: 3,
      altitude: '38,000 FT',
      title: 'Cruising Above the World',
      indicator: 'Standard Cruise',
      description: 'You have surpassed the weather. Below, a perfect blanket of white clouds rolls infinitely, lit by the moon. Perfect, tranquil stillness surrounds the cabin.',
      speed: '480 knots',
      temp: '-54°C',
      view: 'Panoramic skies with stars glowing sharper than ever observed from land.'
    },
    {
      level: 4,
      altitude: '41,000 FT',
      title: 'Stratospheric Gateway',
      indicator: 'Maximum Altitude',
      description: 'At the ultimate cruising boundary. The curvature of the Earth is subtly visible on the horizon, framed by the dark, pristine cosmic void.',
      speed: '495 knots',
      temp: '-59°C',
      view: 'Deep indigo space above, with the brilliant silver ribbon of the atmosphere below.'
    }
  ];

  return (
    <section
      id="journey"
      className="relative min-h-screen py-24 md:py-32 bg-luxury-blue-950 px-6 md:px-12 flex flex-col justify-center items-center"
    >
      {/* Background soft glowing lights */}
      <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] rounded-full bg-blue-900/10 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-gold-400/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        
        {/* Left Column: Narrative storytelling */}
        <div className="lg:col-span-5 space-y-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2.5">
              <Compass className="w-5 h-5 text-gold-400" />
              <span className="font-mono text-xs text-gold-400 tracking-[0.3em] uppercase">
                The Storyline
              </span>
            </div>
            
            <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-white tracking-wider uppercase leading-tight">
              A peaceful flight <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-white to-gold-400 font-light italic">
                above the clouds
              </span>
            </h2>
          </div>

          <p className="text-slate-300 font-sans text-sm sm:text-base leading-relaxed font-light">
            Embarking on a nocturnal flight reveals a peaceful realm that belongs only to those above. The noise of the earth fades, replaced by the deep hum of engines cruising effortlessly through pristine air. 
          </p>

          {/* Staggered Story Steps */}
          <div className="space-y-6" id="story-steps">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-mono text-xs text-gold-400 shrink-0 mt-0.5">
                I
              </div>
              <div>
                <h4 className="font-display font-medium text-white text-sm uppercase tracking-wider">Ascent Into Twilight</h4>
                <p className="text-slate-400 text-xs mt-1 leading-relaxed">Leaving the busy city grids behind as the cabin lights dim to a cozy, eye-safe amber glow.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-mono text-xs text-gold-400 shrink-0 mt-0.5">
                II
              </div>
              <div>
                <h4 className="font-display font-medium text-white text-sm uppercase tracking-wider">Cruising the Stratosphere</h4>
                <p className="text-slate-400 text-xs mt-1 leading-relaxed">Sailing smoothly at thirty-eight thousand feet over infinite clouds lit up like silver fields under a crescent moon.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-mono text-xs text-gold-400 shrink-0 mt-0.5">
                III
              </div>
              <div>
                <h4 className="font-display font-medium text-white text-sm uppercase tracking-wider">Destination Revealed</h4>
                <p className="text-slate-400 text-xs mt-1 leading-relaxed">Descending gently, watching the illuminated silhouette of world landmarks pierce the night fog.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Flight Deck Altitude Explorer */}
        <div className="lg:col-span-7">
          <div 
            className="glass-card rounded-2xl p-6 md:p-8 relative overflow-hidden flex flex-col justify-between min-h-[460px]"
            id="altitude-explorer-card"
          >
            {/* Ambient indicator lights */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-gold-400/5 rounded-full blur-3xl pointer-events-none" />
            
            {/* Instrument Panel Header */}
            <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-6">
              <div className="flex items-center space-x-3">
                <Cloud className="w-5 h-5 text-gold-400" />
                <div>
                  <h3 className="font-display text-xs font-semibold tracking-widest text-white uppercase">ALTITUDE CONTROLLER</h3>
                  <p className="font-mono text-[9px] text-slate-500 uppercase">CABIN PARAMETER HUD v2.4</p>
                </div>
              </div>
              <div className="px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 font-mono text-[10px] text-emerald-400 tracking-wider">
                AUTO_STABLE_CRUISE
              </div>
            </div>

            {/* Main Interactive Slate */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center flex-1">
              {/* Altitude Selector Slider Sidebar */}
              <div className="md:col-span-4 flex flex-row md:flex-col justify-between items-center md:space-y-3 space-x-2 md:space-x-0 border-b md:border-b-0 md:border-r border-white/5 pb-4 md:pb-0 md:pr-4 h-full">
                {flightLevels.map((lvl) => (
                  <button
                    key={lvl.level}
                    onClick={() => setActiveLevel(lvl.level)}
                    className={`w-full py-3.5 px-3 rounded-xl font-mono text-xs transition-all duration-300 flex flex-col items-center justify-center border cursor-pointer ${
                      activeLevel === lvl.level
                        ? 'bg-gold-400/10 border-gold-400 text-gold-400 glow-border-gold font-bold scale-[1.02]'
                        : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:border-white/10 hover:text-white'
                    }`}
                    id={`alt-level-btn-${lvl.level}`}
                  >
                    <span className="text-[10px] opacity-60 uppercase mb-0.5">LEVEL 0{lvl.level}</span>
                    <span className="text-xs tracking-wider">{lvl.altitude}</span>
                  </button>
                ))}
              </div>

              {/* Dynamic Flight Data Screen */}
              <div className="md:col-span-8 space-y-6 md:pl-4 h-full flex flex-col justify-center">
                <AnimatePresence mode="wait">
                  {flightLevels.map((lvl) => {
                    if (lvl.level !== activeLevel) return null;
                    return (
                      <motion.div
                        key={lvl.level}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.4 }}
                        className="space-y-4"
                        id={`alt-level-data-${lvl.level}`}
                      >
                        <div className="flex items-center space-x-2">
                          <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[9px] font-mono text-slate-400 uppercase tracking-widest">
                            {lvl.indicator}
                          </span>
                        </div>
                        
                        <h4 className="font-display font-bold text-xl sm:text-2xl text-white tracking-wide uppercase">
                          {lvl.title}
                        </h4>
                        
                        <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-light">
                          {lvl.description}
                        </p>

                        {/* Real-time telemetry feed */}
                        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/5 font-mono text-[11px]">
                          <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                            <span className="text-slate-500 block mb-0.5">AIR SPEED</span>
                            <span className="text-white font-medium tracking-wide">{lvl.speed}</span>
                          </div>
                          <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                            <span className="text-slate-500 block mb-0.5">EXT TEMPERATURE</span>
                            <span className="text-rose-400 font-medium tracking-wide">{lvl.temp}</span>
                          </div>
                        </div>

                        <div className="bg-gold-400/5 border border-gold-400/10 rounded-xl p-3 flex items-start space-x-2.5">
                          <Navigation className="w-4 h-4 text-gold-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-mono text-[10px] text-gold-400/80 block uppercase tracking-wider">WINDOW PERSPECTIVE</span>
                            <p className="text-slate-300 text-xs mt-0.5 font-light">{lvl.view}</p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>

            {/* Altitude slider visualization bar */}
            <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between font-mono text-[10px] text-slate-500">
              <span className="flex items-center space-x-1">
                <Sparkles className="w-3 h-3 text-gold-400" />
                <span>INTERACTIVE HUD PANEL</span>
              </span>
              <span>SIMULATED ALTITUDE</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
