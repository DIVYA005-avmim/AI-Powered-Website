import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plane, Menu, X, Compass, Radio } from 'lucide-react';

interface NavbarProps {
  currentSection: string;
}

export default function Navbar({ currentSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [coordinates, setCoordinates] = useState('N 48° 51\' 24" / E 2° 21\' 8"');

  // Smooth scroll helper
  const handleScrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Slowly cycle coordinates to mimic flight progress
  useEffect(() => {
    const coords = [
      'N 48° 51\' 24" / E 2° 21\' 8"',   // Paris
      'N 35° 41\' 22" / E 139° 41\' 30"', // Tokyo
      'N 4° 10\' 30" / E 73° 30\' 32"',   // Maldives
      'N 40° 42\' 46" / W 74° 0\' 21"',   // New York
    ];
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % coords.length;
      setCoordinates(coords[index]);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { name: 'Home', id: 'home' },
    { name: 'Journey', id: 'journey' },
    { name: 'Destinations', id: 'destinations' },
    { name: 'Experience', id: 'experience' },
  ];

  return (
    <header
      id="main-nav"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-luxury-blue-950/70 border-b border-white/5 py-4 backdrop-blur-xl'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => handleScrollTo('home')} 
          className="flex items-center space-x-3 cursor-pointer group"
          id="nav-logo"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-gold-400/10 border border-gold-400/20 group-hover:border-gold-400/50 transition-all duration-500">
            <Plane className="w-5 h-5 text-gold-400 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-500" />
            <span className="absolute inset-0 rounded-full border border-gold-400/20 animate-ping opacity-25"></span>
          </div>
          <div>
            <span className="font-display font-bold tracking-[0.2em] text-white text-lg block leading-none">
              SKYLINE
            </span>
            <span className="font-mono text-[9px] text-gold-400/80 tracking-widest block uppercase mt-1">
              Above The Sky
            </span>
          </div>
        </div>

        {/* Live Flight Telemetry (Floating UI element) */}
        <div className="hidden lg:flex items-center space-x-6 px-4 py-1.5 rounded-full bg-white/5 border border-white/5 font-mono text-[11px] text-slate-400">
          <div className="flex items-center space-x-2">
            <Radio className="w-3.5 h-3.5 text-gold-400 animate-pulse" />
            <span className="text-gold-400/80 uppercase">FLIGHT 707</span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="flex items-center space-x-1">
            <span className="text-slate-500">POS:</span>
            <span className="text-slate-300 font-medium tracking-wide">{coordinates}</span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="flex items-center space-x-1">
            <span className="text-slate-500">ALT:</span>
            <span className="text-emerald-400 font-medium">38,000 FT</span>
          </div>
        </div>

        {/* Navigation items (Desktop) */}
        <nav className="hidden md:flex items-center space-x-1 md:space-x-8" id="desktop-nav">
          {navItems.map((item) => {
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleScrollTo(item.id)}
                className="relative py-2 px-3 font-display text-sm tracking-widest text-slate-300 hover:text-white uppercase transition-colors duration-300 cursor-pointer"
                id={`nav-link-${item.id}`}
              >
                {item.name}
                {isActive && (
                  <motion.span
                    layoutId="navbar-active-indicator"
                    className="absolute bottom-0 left-3 right-3 h-[2px] bg-gold-400 glow-border-gold rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
          
          <button
            onClick={() => handleScrollTo('experience')}
            className="px-5 py-2 rounded-full font-display text-xs tracking-widest text-gold-400 border border-gold-400/30 hover:border-gold-400 hover:bg-gold-400/10 transition-all duration-300 uppercase cursor-pointer"
            id="nav-btn-experience"
          >
            Boarding
          </button>
        </nav>

        {/* Hamburger (Mobile) */}
        <div className="md:hidden flex items-center space-x-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-white p-2 focus:outline-none"
            id="mobile-nav-toggle"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="absolute top-full left-0 right-0 glass-panel border-b border-white/10 p-6 md:hidden flex flex-col space-y-4"
            id="mobile-nav-menu"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleScrollTo(item.id)}
                className={`text-left font-display text-sm uppercase tracking-widest py-2.5 border-b border-white/5 ${
                  currentSection === item.id ? 'text-gold-400' : 'text-slate-300'
                }`}
                id={`mobile-nav-link-${item.id}`}
              >
                {item.name}
              </button>
            ))}
            
            <div className="flex justify-between items-center py-2 text-[10px] font-mono text-slate-400">
              <span>FLIGHT 707 TELEMETRY</span>
              <span className="text-gold-400 font-bold">ALT 38K FT</span>
            </div>
            
            <button
              onClick={() => handleScrollTo('experience')}
              className="w-full py-3 rounded-xl bg-gold-400 text-slate-950 font-display text-xs tracking-widest font-semibold hover:bg-gold-500 transition-colors uppercase text-center"
              id="mobile-nav-btn-boarding"
            >
              Begin Immersive Boarding
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
