/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Journey from './components/Journey';
import Destinations from './components/Destinations';
import Experience from './components/Experience';
import Footer from './components/Footer';

export default function App() {
  const [currentSection, setCurrentSection] = useState('home');

  useEffect(() => {
    const sections = ['home', 'journey', 'destinations', 'experience'];
    
    const observerOptions = {
      root: null,
      rootMargin: '-30% 0px -50% 0px', // Trigger when the section occupies the focal view area
      threshold: 0,
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setCurrentSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    sections.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });

    return () => {
      sections.forEach((id) => {
        const element = document.getElementById(id);
        if (element) observer.unobserve(element);
      });
    };
  }, []);

  const handleBeginJourney = () => {
    const journeySection = document.getElementById('journey');
    if (journeySection) {
      journeySection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-luxury-blue-950 text-slate-100 overflow-x-hidden selection:bg-gold-400/30 selection:text-white relative font-sans" id="app-root">
      {/* Background radial atmosphere gradient wrapper */}
      <div className="absolute inset-0 radial-night-gradient pointer-events-none z-0" />
      
      {/* Navigation */}
      <Navbar currentSection={currentSection} />

      {/* Main Sections */}
      <main className="relative z-10">
        <Hero onBeginJourney={handleBeginJourney} />
        <Journey />
        <Destinations />
        <Experience />
      </main>

      {/* Footer / Contact */}
      <Footer />
    </div>
  );
}

